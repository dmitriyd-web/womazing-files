<template>
    <section class="page">
        <div class="container">
            <div class="row">
                <div class="title">
                    <h1>Магазин</h1>
                </div>
                <nav class="breadcrumb">
                    <ul>
                        <li>
                            <router-link to="/">Главная</router-link>
                        </li>
                        <li>
                            <span>—</span>
                        </li>
                        <li>
                            <router-link class="current-page" to="/">Магазин</router-link>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </section>
    <section class="products products-shop">
        <div class="container">
            <div class="row">
                <router-link class="product" to="/tovar"
                    v-if="!tovarsArray"
                    v-for="(tovar, index) in this.$store.state.tovars.slice(0, 8)"
                    :key="tovar"
                    @click="setCurrentTovar(this.tovarsArray[index].id)"
                >
                    <div class="product-image">
                        <div class="product-image__shadow">
                            <img src="../assets/images/arrow-product.svg">
                        </div>
                        <img class="product-photo" :src="this.$store.state.tovars[index].photo">
                    </div>
                    <p class="product-name">{{ this.$store.state.tovars[index].name }}</p>
                    <p class="product-priсes">
                        <span class="full-price" 
                            v-if="this.$store.state.tovars[index].full_price != ''"
                        >${{ this.$store.state.tovars[index].full_price }}
                        </span>
                        <span class="discount-price" 
                            v-if="this.$store.state.tovars[index].discount_price != ''"
                        >${{ this.$store.state.tovars[index].discount_price }}
                        </span>
                    </p>
                </router-link>
                <router-link class="product" to="/tovar"
                    v-else
                    v-for="(showTovar, index) in this.tovarsArray"
                    :key="showTovar"
                    @click="setCurrentTovar(this.tovarsArray[index].id)"
                >
                    <div class="product-image">
                        <div class="product-image__shadow">
                            <img src="../assets/images/arrow-product.svg">
                        </div>
                        <img class="product-photo" :src="this.$store.state.tovars[index].photo">
                    </div>
                    {{ index }}
                    <p class="product-name">{{ this.$store.state.tovars[index].name }}</p>
                    <p class="product-priсes">
                        <span class="full-price" 
                            v-if="this.$store.state.tovars[index].full_price != ''"
                        >${{ this.$store.state.tovars[index].full_price }}
                        </span>
                        <span class="discount-price" 
                            v-if="this.$store.state.tovars[index].discount_price != ''"
                        >${{ this.$store.state.tovars[index].discount_price }}
                        </span>
                    </p>
                </router-link>
                <ul class="pagination">
                    <li
                        v-for="(item, index) in this.allPaginationCount"
                    >
                        <a
                            v-bind:class="[((index + 1) == this.currentPage) ? 'current' : '']"
                            @click="changePage(index + 1)"
                        >{{ index + 1 }}</a>
                    </li>
                </ul>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                currentPage: 1,
                allPages: this.$store.state.tovars.map(item => item.name).length,
                allPaginationCount: 0,
                tovarsArray: []
            }
        },
        mounted(){
            this.allPaginationCount = Math.floor(this.$store.state.tovars.map(item => item.name).length / 9) + 1
            this.tovarsArray = this.$store.state.tovars.slice(0, 9)
            console.log(this.tovarsArray)
            console.log(this.allPaginationCount)
        },
        methods: {
            setCurrentTovar(tovarId) {
                this.$store.commit('setCurrentTovar', tovarId)
            },
            changePage(pageNumber) {
                console.log(this.currentPage)
                console.log(this.allPaginationCount)
                /*
                console.log(this.currentPage)
                console.log(this.allPaginationCount)
                if (this.currentPage < this.allPaginationCount) {
                    this.currentPage++
                }   else {
                    this.currentPage--
                }
                console.log(this.tovarsArray)
                let i = this.currentPage * 8
                for ( i; i <= this.allPages; i++) {
                    this.tovarsArray = []
                    this.tovarsArray = this.tovarsArray.push(this.$store.state.tovars[i])
                }
                console.log(this.tovarsArray)
                */
                if (this.currentPage < this.allPaginationCount) {
                    this.currentPage++
                }   else {
                    this.currentPage--
                }
                console.log(this.currentPage)
                console.log(this.allPaginationCount)
                //this.tovarsArray = this.$store.state.tovars
                //console.log(this.tovarsArray)
                //this.tovarsArray = this.tovarsArray.splice(5, 12)
                console.log(this.allPages)
            }
        }
    }
    
</script>